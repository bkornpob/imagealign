# ImageAlign

Webpage: ???

ImageAlign is a class to facilitate aligning two images by matching centroids of sources in pixel (x,y) coordinate.


## 1.0.0
Initial release